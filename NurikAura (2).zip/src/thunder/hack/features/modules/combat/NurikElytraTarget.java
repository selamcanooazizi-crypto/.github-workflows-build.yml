package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

import java.util.Comparator;
import java.util.Random;

/**
 * NurikElytraTarget - Nursultan ElytraTarget ("Komar - Peregon") fikrinin Wexa icin YENIDEN YAZIMI.
 * Nursultan'in fH sinifi okunabilir kaynak olarak yok; bu dosya onun birebir kopyasi DEGIL.
 * Sadece sabit havuzdan gorulen seyler kullanildi: acik/kapali mesaji, atan2/hypot/clamp, rastgele jitter.
 * Derlenip oyunda DENENMEDI.
 */
public class NurikElytraTarget extends Module {

    public final Setting<Float> range = new Setting<>("Range", 60.0f, 10.0f, 200.0f);
    public final Setting<Float> yawSpeed = new Setting<>("YawSpeed", 60.0f, 5.0f, 180.0f);
    public final Setting<Float> pitchSpeed = new Setting<>("PitchSpeed", 15.0f, 3.0f, 90.0f);
    public final Setting<Float> jitter = new Setting<>("Jitter", 1.0f, 0.0f, 5.0f);
    public final Setting<Boolean> predict = new Setting<>("Predict", true);
    public final Setting<Boolean> ignoreFriends = new Setting<>("IgnoreFriends", true);
    public final Setting<Boolean> onlyElytra = new Setting<>("OnlyWhileFlying", true);

    public static PlayerEntity target;
    public static Vec3d predictedPos;

    private final Random rnd = new Random();

    public NurikElytraTarget() {
        super("NurikElytraTarget", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        if (!fullNullCheck()) sendMessage("Komar - Перегон Включен");
    }

    @Override
    public void onDisable() {
        target = null;
        predictedPos = null;
        if (!fullNullCheck()) sendMessage("Komar - Перегон Выключен");
    }

    @EventHandler
    public void onSync(EventSync e) {
        if (fullNullCheck()) return;
        if (onlyElytra.getValue() && !mc.player.isFallFlying()) { target = null; return; }

        target = findTarget();
        if (target == null) return;

        Vec3d eye = mc.player.getEyePos();
        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.5, 0);

        if (predict.getValue()) {
            double dist = eye.distanceTo(pos);
            double mySpeed = Math.max(mc.player.getVelocity().length(), 0.5);
            double ticks = MathHelper.clamp(dist / mySpeed, 0, 20);
            pos = pos.add(target.getVelocity().multiply(ticks));
        }
        predictedPos = pos;

        double dx = pos.x - eye.x, dy = pos.y - eye.y, dz = pos.z - eye.z;
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float curYaw = mc.player.getYaw();
        float curPitch = mc.player.getPitch();

        float dYaw = MathHelper.wrapDegrees(wantYaw - curYaw);
        float dPitch = wantPitch - curPitch;

        float sy = MathHelper.clamp(dYaw, -yawSpeed.getValue(), yawSpeed.getValue())
                + (rnd.nextFloat() - 0.5f) * 2f * jitter.getValue();
        float sp = MathHelper.clamp(dPitch, -pitchSpeed.getValue(), pitchSpeed.getValue())
                + (rnd.nextFloat() - 0.5f) * jitter.getValue();

        float ny = curYaw + sy;
        float np = MathHelper.clamp(curPitch + sp, -90f, 90f);

        e.setYaw(ny);
        e.setPitch(np);
        mc.player.setYaw(ny);
        mc.player.setPitch(np);
    }

    private PlayerEntity findTarget() {
        return mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive() && !p.isSpectator())
                .filter(p -> mc.player.distanceTo(p) <= range.getValue())
                .filter(p -> !(ignoreFriends.getValue() && Managers.FRIEND.isFriend(p)))
                .min(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(p)))
                .orElse(null);
    }
}
