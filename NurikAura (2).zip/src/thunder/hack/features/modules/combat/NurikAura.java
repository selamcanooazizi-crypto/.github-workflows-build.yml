package thunder.hack.features.modules.combat;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import thunder.hack.core.Managers;
import thunder.hack.events.impl.EventSync;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

import java.util.Comparator;
import java.util.Optional;
import java.util.Random;

/**
 * NurikAura - Nursultan AttackAura'sinin rotasyon mantigi (FT, Grim, SpookyTime, Noise, HW)
 * Wexa (Fabric 1.21.x, Yarn) icin yeniden yazildi.
 *
 * Kaynak: rotation_kritik_sprint_tr/ analizi + class11084/11103/11071/11091/11069/11076.
 * NOT: Bu dosya derlenip oyunda DENENMEDI. Yaklasik yapilan kisimlar "APPROX" ile isaretli.
 */
public class NurikAura extends Module {

    public enum RotMode { FT, Grim, SpookyTime, Noise, HW }
    public enum WeaponMode { Normal, None }

    public final Setting<Float> range = new Setting<>("Range", 3.0f, 1.0f, 6.0f);
    public final Setting<Float> aimRange = new Setting<>("AimRange", 4.5f, 1.0f, 8.0f);
    public final Setting<RotMode> rotationMode = new Setting<>("RotationMode", RotMode.FT);
    public final Setting<WeaponMode> autoWeapon = new Setting<>("AutoWeapon", WeaponMode.Normal);
    public final Setting<Boolean> onlyCrit = new Setting<>("OnlyCrit", true);
    public final Setting<Boolean> critOnlySpace = new Setting<>("CriticalOnlySpace", false);
    public final Setting<Boolean> clientLook = new Setting<>("ClientLook", false);
    public final Setting<Boolean> rayTrace = new Setting<>("RayTrace", true);
    public final Setting<Boolean> players = new Setting<>("Players", true);
    public final Setting<Boolean> mobs = new Setting<>("Mobs", true);
    public final Setting<Boolean> animals = new Setting<>("Animals", false);
    public final Setting<Boolean> ignoreFriends = new Setting<>("IgnoreFriends", true);
    public final Setting<Boolean> ignoreInvisible = new Setting<>("IgnoreInvisible", false);

    public static Entity target;

    private final Random rnd = new Random();

    // ortak durum
    private int ticksSinceAttack = 100;
    private int hitCount = 0;            // Spooky-time ritmi icin (count % 4 == 0 -> 13 tick)
    private int updateCount = 0;         // class11799.N() == 1 -> "ilk guncelleme"
    private float lastYaw, lastPitch;
    private boolean rotInit = false;

    // Grim durumu
    private boolean grimHold = false;
    // HW durumu
    private int hwCounter = 0;
    // Spooky durumu
    private int spookyTargetId = -1;
    private double spookyPhase = 0;
    private int spookyRegion = 0;
    private long spookyRegionUntil = 0;

    public NurikAura() {
        super("NurikAura", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        rotInit = false;
        updateCount = 0;
        grimHold = false;
        hwCounter = 0;
        spookyTargetId = -1;
    }

    @Override
    public void onDisable() {
        target = null;
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck()) return;
        ticksSinceAttack++;
    }

    // ---------------------------------------------------------------- ana dongu

    @EventHandler
    public void onSync(EventSync e) {
        if (fullNullCheck()) return;

        target = findTarget();
        if (target == null) {
            updateCount = 0;
            return;
        }
        updateCount++;

        if (!rotInit) {
            lastYaw = mc.player.getYaw();
            lastPitch = mc.player.getPitch();
            rotInit = true;
        }

        boolean b = canAttackNow(target); // ortak "bu tur saldiri serbest mi" bayragi

        float[] step = computeStep(target, b);
        float curYaw = lastYaw;
        float curPitch = lastPitch;

        float newYaw = curYaw + step[0];
        float newPitch = MathHelper.clamp(curPitch + step[1], -90f, 90f);

        // GCD duzeltmesi (mouse hassasiyeti)
        float[] g = gcdFix(newYaw, newPitch, curYaw, curPitch);
        newYaw = g[0];
        newPitch = g[1];

        lastYaw = newYaw;
        lastPitch = newPitch;

        e.setYaw(newYaw);
        e.setPitch(newPitch);
        if (clientLook.getValue()) {
            mc.player.setYaw(newYaw);
            mc.player.setPitch(newPitch);
        }

        final float fy = newYaw, fp = newPitch;
        if (b && (!rayTrace.getValue() || lookingAt(target, fy, fp))) {
            e.addPostAction(() -> attack(target));
        }
    }

    // ---------------------------------------------------------------- rotasyon modlari

    private float[] computeStep(Entity t, boolean b) {
        Vec3d eye = mc.player.getEyePos();
        double aim = (rotationMode.getValue() == RotMode.HW) ? range.getValue() : aimRange.getValue();
        Vec3d point = aimPoint(t, eye, aim);

        float[] want = anglesTo(eye, point);
        float dYaw = MathHelper.wrapDegrees(want[0] - lastYaw);
        float dPitch = want[1] - lastPitch;

        // class11084/11103/11071: updateCount == 1 -> mevcut rotasyonu dondur
        boolean first = updateCount == 1;
        int tick = mc.player.age;

        switch (rotationMode.getValue()) {
            case FT: {
                if (first) return new float[]{0, 0};
                float sy, sp;
                if (b) {
                    sy = dYaw + gauss(2.0f);
                } else {
                    float r = uniform(40f, 60f);
                    sy = sat(dYaw, r) + (waveM(tick) * 10f + gauss(2.5f)); // APPROX: class04995.m(tick)
                }
                sp = sat(dPitch, 8f) + (waveP(tick) * 4f + gauss(1.0f));    // APPROX: class04995.P(tick)
                return new float[]{sy, sp};
            }
            case Grim: {
                // 1) guncelleme > 1 ve b == false -> bayrak true, acıyı koru
                if (updateCount > 1 && !b) {
                    grimHold = true;
                    return new float[]{0, 0};
                }
                // 2) b == true iken ray hedefi vurmuyorsa -> acıyı koru, bayrak false
                if (b && !lookingAt(t, lastYaw, lastPitch)) {
                    // (kaynakta ozel durum; ray hedefi isabet ettirmiyorsa tutma dali)
                    grimHold = false;
                    // devam: asagida dogrudan donus uygulanir
                } else if (b && lookingAt(t, lastYaw, lastPitch)) {
                    grimHold = false;
                    return new float[]{0, 0};
                }
                float f = grimHold ? uniform(7f, 13f) : 0f;
                float sy = b ? dYaw : f;
                float sp = b ? dPitch : (mc.player.getPitch() > 0f ? -f : f);
                return new float[]{sy, sp};
            }
            case Noise: {
                if (first) return new float[]{0, 0};
                float sy = sat(dYaw, 45f) + (b ? 0f : gauss(5f));
                float sp = sat(dPitch, 5f) + (b ? 0f : gauss(1f));
                return new float[]{sy, sp};
            }
            case HW: {
                if (hwCounter > 0) hwCounter--;
                if (b) hwCounter = 2;
                if (hwCounter == 0) return new float[]{0, 0};
                float r = (float) Math.hypot(Math.abs(dYaw), Math.abs(dPitch));
                if (r < 1.0E-4f) return new float[]{gauss(0.6f), gauss(0.3f)}; // kaynakta koruma yok, biz ekledik
                float limY = Math.abs(dYaw / r) * 360f;
                float limP = Math.abs(dPitch / r) * 360f;
                float sy = Math.min(Math.max(dYaw, -limY), limY) + gauss(0.6f);
                float sp = Math.min(Math.max(dPitch, -limP), limP) + gauss(0.3f);
                return new float[]{sy, sp};
            }
            case SpookyTime:
            default:
                return spookyStep(t, eye);
        }
    }

    /**
     * Spooky-time (class11069/11076/11095) - SADELESTIRILMIS port:
     * hareket tahmini + govde bolgesi + zamanli sinus ofseti + aday nokta maliyeti.
     * Planlayici ic durumlari (p bayragi) APPROX: p = hedef yakin menzilde.
     */
    private float[] spookyStep(Entity t, Vec3d eye) {
        if (t.getId() != spookyTargetId) { // hedef degisti -> sifirla
            spookyTargetId = t.getId();
            spookyPhase = rnd.nextDouble() * Math.PI * 2;
            spookyRegionUntil = 0;
        }
        Box box = t.getBoundingBox();
        double D = Math.sqrt(eye.squaredDistanceTo(clampToBox(eye, box)));
        boolean p = D < 2.4; // APPROX

        Vec3d vT = t.getVelocity();
        Vec3d vP = mc.player.getVelocity();
        double vx = vT.x - 0.42 * vP.x, vz = vT.z - 0.42 * vP.z;
        double V = Math.hypot(vx, vz);
        double q = p ? MathHelper.clamp(D * 0.18 + V * 2.4, 0.18, 1.25)
                     : MathHelper.clamp(D * 0.46 + V * 5.8, 0.85, 5.20);

        // bolge secimi (agirliklar kaynak tablosundan)
        long now = System.currentTimeMillis();
        if (now >= spookyRegionUntil) {
            double[] w = p ? new double[]{0.38, 0.38, 0.15, 0.09} : new double[]{0.46, 0.30, 0.16, 0.08};
            double x = rnd.nextDouble(), acc = 0;
            spookyRegion = 0;
            for (int i = 0; i < 4; i++) { acc += w[i]; if (x <= acc) { spookyRegion = i; break; } }
            spookyRegionUntil = now + 58 + rnd.nextInt(147); // 58..205 ms
        }
        double h = box.getLengthY();
        double[] yFrac = {0.78, 0.86, 0.62, 0.95}; // UPPER_CHEST, SHOULDER, MID_CHEST, HEAD_LINE
        Vec3d c = box.getCenter();
        Vec3d p0 = new Vec3d(c.x, box.minY + h * yFrac[spookyRegion], c.z);

        Vec3d pred = new Vec3d(
                p0.x + vx * q,
                p0.y + vT.y * MathHelper.clamp(0.42 * q, 0, 1.45),
                p0.z + vz * q);
        pred = clampToBox(pred, box.contract(0.02));

        double a = p ? 0.014 : 0.046;
        double tm = now;
        pred = pred.add(
                Math.sin(tm * 0.0105 + spookyPhase) * box.getLengthX() * a,
                Math.cos(tm * 0.0073 + spookyPhase * 0.73) * h * a * 0.28,
                Math.sin(tm * 0.0121 + spookyPhase * 1.31) * box.getLengthZ() * a);
        pred = clampToBox(pred, box.contract(0.02));

        // aday nokta maliyeti: 9 aday, en ucuz gecerli olan
        Vec3d best = pred;
        double bestCost = Double.MAX_VALUE;
        float[] ref = anglesTo(eye, pred);
        double refY = pred.y;
        for (Vec3d cand : candidates(box, pred)) {
            float[] ca = anglesTo(eye, cand);
            double cost = 0.86 * Math.abs(MathHelper.wrapDegrees(ca[0] - ref[0]))
                    + 4.20 * Math.abs(ca[1] - ref[1])
                    + 3.80 * Math.max(0, cand.y - refY)
                    + 0.01 * eye.squaredDistanceTo(cand);
            if (cost < bestCost && box.raycast(eye, cand).isPresent()) {
                bestCost = cost;
                best = cand;
            }
        }

        float[] want = anglesTo(eye, best);
        float dYaw = MathHelper.wrapDegrees(want[0] - lastYaw);
        float dPitch = want[1] - lastPitch;
        // APPROX: gorus adimi filtresi (class11095) - dogrusal olmayan yumusatma
        return new float[]{sat(dYaw, 60f), sat(dPitch, 12f)};
    }

    private Vec3d[] candidates(Box box, Vec3d around) {
        Box in = box.contract(0.05, 0.05, 0.05);
        double[] ys = {in.minY + in.getLengthY() * 0.55, in.minY + in.getLengthY() * 0.75, in.minY + in.getLengthY() * 0.9};
        Vec3d c = in.getCenter();
        Vec3d[] out = new Vec3d[9];
        int i = 0;
        for (double y : ys) {
            out[i++] = new Vec3d(c.x, y, c.z);
            out[i++] = new Vec3d(in.minX, y, in.minZ);
            out[i++] = new Vec3d(in.maxX, y, in.maxZ);
        }
        return out;
    }

    // ---------------------------------------------------------------- saldiri

    private boolean canAttackNow(Entity t) {
        if (mc.player.squaredDistanceTo(t) > range.getValue() * range.getValue() + 1.0) return false;
        if (mc.player.getAttackCooldownProgress(0.5f) < 0.93f) return false;

        // ortak vurus araligi 10 tick; Spooky-time'da count % 4 == 0 ise 13
        int interval = 10;
        if (rotationMode.getValue() == RotMode.SpookyTime && hitCount % 4 == 0) interval += 3;
        if (ticksSinceAttack < interval) return false;

        if (onlyCrit.getValue()) {
            boolean inLiquid = mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.isClimbing();
            boolean crit = mc.player.fallDistance > 0.0f && !mc.player.isOnGround() && !inLiquid;
            if (!crit && !inLiquid) return false;
        }
        if (critOnlySpace.getValue() && mc.player.isOnGround() && !mc.options.jumpKey.isPressed()) return false;
        return true;
    }

    private void attack(Entity t) {
        if (t == null || mc.interactionManager == null) return;

        if (autoWeapon.getValue() == WeaponMode.Normal) {
            int slot = bestWeaponSlot();
            if (slot != -1 && slot != mc.player.getInventory().selectedSlot) {
                mc.player.getInventory().selectedSlot = slot;
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            }
        }
        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
        ticksSinceAttack = 0;
        hitCount++;
    }

    private int bestWeaponSlot() {
        int best = -1, bestScore = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            int score = s.isIn(ItemTags.SWORDS) ? 2 : s.isIn(ItemTags.AXES) ? 1 : 0;
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }

    // ---------------------------------------------------------------- hedef

    private Entity findTarget() {
        double r = Math.max(range.getValue(), aimRange.getValue());
        Optional<Entity> o = mc.world.getEntitiesByClass(LivingEntity.class,
                        mc.player.getBoundingBox().expand(r + 1.0), this::valid).stream()
                .map(e -> (Entity) e)
                .min(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)));
        return o.orElse(null);
    }

    private boolean valid(LivingEntity e) {
        if (e == mc.player || !e.isAlive() || e.getHealth() <= 0) return false;
        if (mc.player.squaredDistanceTo(e) > aimRange.getValue() * aimRange.getValue()) return false;
        if (ignoreInvisible.getValue() && e.isInvisible()) return false;
        if (e instanceof PlayerEntity p) {
            if (!players.getValue()) return false;
            if (ignoreFriends.getValue() && Managers.FRIEND.isFriend(p)) return false;
            return true;
        }
        if (e instanceof HostileEntity) return mobs.getValue();
        if (e instanceof AnimalEntity) return animals.getValue();
        return mobs.getValue();
    }

    // ---------------------------------------------------------------- yardimcilar

    private Vec3d aimPoint(Entity t, Vec3d eye, double aim) {
        Box b = t.getBoundingBox().contract(0.05);
        double h = b.getLengthY();
        Vec3d p = new Vec3d(
                MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY + h * 0.25, b.maxY - h * 0.1),
                MathHelper.clamp(eye.z, b.minZ, b.maxZ));
        return p;
    }

    private Vec3d clampToBox(Vec3d v, Box b) {
        return new Vec3d(MathHelper.clamp(v.x, b.minX, b.maxX),
                MathHelper.clamp(v.y, b.minY, b.maxY),
                MathHelper.clamp(v.z, b.minZ, b.maxZ));
    }

    /** class11505: yaw = wrap(deg(atan2(dz,dx)) - 90), pitch = -deg(atan2(dy,h)) */
    private float[] anglesTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = MathHelper.wrapDegrees((float) Math.toDegrees(Math.atan2(dz, dx)) - 90f);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, pitch};
    }

    private boolean lookingAt(Entity t, float yaw, float pitch) {
        Vec3d eye = mc.player.getEyePos();
        float fy = -yaw * 0.017453292f - (float) Math.PI;
        float fp = -pitch * 0.017453292f;
        float cy = MathHelper.cos(fy), sy = MathHelper.sin(fy), cp = -MathHelper.cos(fp), sp = MathHelper.sin(fp);
        Vec3d dir = new Vec3d(sy * cp, sp, cy * cp);
        Vec3d end = eye.add(dir.multiply(range.getValue() + 0.5));
        return t.getBoundingBox().expand(t.getTargetingMargin()).raycast(eye, end).isPresent();
    }

    private float[] gcdFix(float yaw, float pitch, float prevYaw, float prevPitch) {
        double sens = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        double gcd = sens * sens * sens * 8.0 * 0.15;
        float y = prevYaw + (float) (Math.round((yaw - prevYaw) / gcd) * gcd);
        float p = prevPitch + (float) (Math.round((pitch - prevPitch) / gcd) * gcd);
        return new float[]{y, MathHelper.clamp(p, -90f, 90f)};
    }

    /** c * tanh(x / c) */
    private float sat(float x, float c) { return (float) (c * Math.tanh(x / c)); }

    private float gauss(float sigma) { return (float) (rnd.nextGaussian() * sigma); }

    private float uniform(float a, float b) { return a + rnd.nextFloat() * (b - a); }

    // APPROX: Nursultan'daki class04995.m(tick) / P(tick) bu pakette yok; dalga olarak yaklasik
    private float waveM(int tick) { return (float) Math.sin(tick * 0.37); }
    private float waveP(int tick) { return (float) Math.cos(tick * 0.29); }
}
