# NurikAura (Wexa icin)

Dosya: src/thunder/hack/features/modules/combat/NurikAura.java

## Kurulum (Wexa kaynak reposunda)
1. Dosyayi `thunder/hack/features/modules/combat/` altina koy.
2. `ModuleManager` icinde diger combat modullerinin yanina ekle:
       registerModule(new NurikAura());
3. Derle (gradle build). Hata cikarsa hata ciktisini Claude'a ver.

## Icinde ne var
- Rotasyon modlari: FT, Grim, SpookyTime, Noise, HW (Nursultan AttackAura analizindeki formuller)
- AutoWeapon: Normal (hotbar'dan kilic/balta secer) / None
- OnlyCrit, CriticalOnlySpace, RayTrace, ClientLook, hedef filtreleri

## Henuz yapilmayanlar
- Wexa'nin eski Aura'sini silme / ElytraTarget degistirme / SuperFirework'u ElytraBooster altina tasima
- Wexa'nin kendi FunTime/SpookyTime/Track modlarini bu modula baglama
- Sprint sayaclari (R3/R4/R6)

## Yaklasik yapilanlar ("APPROX")
- FT'deki class04995.m/P(tick) dalgalari (kaynak pakette yok)
- Spooky-time'in ic p bayragi ve adim filtresi
- Grim'in ray ozel durumu

## NurikElytraTarget (ek)
Dosya: src/thunder/hack/features/modules/combat/NurikElytraTarget.java
- Nursultan'in ElytraTarget'i okunabilir olmadigi icin birebir kopya DEGIL, ayni fikirde yeniden yazim.
- Elytra ile ucarken en yakin oyuncuyu kovalar (hiz tahminli), yaw/pitch hizi sinirli, kucuk jitter.
- Kurulum: ModuleManager'a  registerModule(new NurikElytraTarget());
- Wexa'nin normal ElytraTarget'i dokunulmadan durur.
- SuperFirework yok (Nursultan'da bulunamadi).
