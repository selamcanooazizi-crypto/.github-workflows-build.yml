NurikAura source integration bundle

Files are placed in the expected Java package path:
src/main/java/thunder/hack/features/modules/combat/

These are source modules, NOT a standalone Fabric mod. They depend on host-client APIs
such as thunder.hack.features.modules.Module, Setting, Managers, EventSync, and Orbit.
A full host project (Gradle build files, Fabric Loom setup, Minecraft mappings,
mod metadata, and dependency sources/artifacts) is required to compile them.

Copy the Java files into the matching package in your existing host-client repository.
Do not run Gradle from this bundle: it intentionally has no standalone build.gradle.
